This directory consists of extended configuration files.
Modifying these are not required, and are for users who want a customized setup.
- Vampire