class Category_602 {
	class G36A_camo {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class G36C {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class G36C_camo {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class G36K_camo {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class M16A2 {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class M16A2GL {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class M16A4_ACG {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class M4A1 {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class M4A1_HWS_GL_camo {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class M4A3_CCO_EP1 {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class M4A1_Aim {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class Sa58P_EP1 {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Sa58V_CCO_EP1 {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class Sa58V_EP1 {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Sa58V_RCO_EP1 {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class AKS_74_kobra {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class AKS_74_U {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class AK_47_M {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class AK_74 {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class FN_FAL {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class BAF_L85A2_RIS_SUSAT {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class BAF_L85A2_RIS_Holo {
		type = "trade_weapons";
		buy[] ={9000,"Coins"};
		sell[] ={4500,"Coins"};
	};
};
class Category_637 {
	class G36A_camo {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class G36C {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class G36C_camo {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class G36K_camo {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class M16A2 {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class M16A2GL {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class M16A4_ACG {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class M4A1 {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class M4A1_HWS_GL_camo {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class M4A3_CCO_EP1 {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class M4A1_Aim {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class Sa58P_EP1 {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Sa58V_CCO_EP1 {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class Sa58V_EP1 {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Sa58V_RCO_EP1 {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class AKS_74_kobra {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class AKS_74_U {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class AK_47_M {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class AK_74 {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class FN_FAL {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class BAF_L85A2_RIS_SUSAT {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class BAF_L85A2_RIS_Holo {
		type = "trade_weapons";
		buy[] ={9000,"Coins"};
		sell[] ={4500,"Coins"};
	};
};
