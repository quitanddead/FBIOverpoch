class Category_655 {
	class KamazRefuel_DZ {
		type = "trade_any_vehicle";
		buy[] ={80000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class MtvrRefuel_DES_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] ={80000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class UralRefuel_TK_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] ={80000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class V3S_Refuel_TK_GUE_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] ={80000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class MtvrRefuel_DZ {
		type = "trade_any_vehicle";
		buy[] ={80000,"Coins"};
		sell[] ={40000,"Coins"};
	};
};
class Category_589 {
	class KamazRefuel_DZ {
		type = "trade_any_vehicle";
		buy[] ={80000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class MtvrRefuel_DES_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] ={80000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class UralRefuel_TK_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] ={80000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class V3S_Refuel_TK_GUE_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] ={80000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class MtvrRefuel_DZ {
		type = "trade_any_vehicle";
		buy[] ={80000,"Coins"};
		sell[] ={40000,"Coins"};
	};
};
