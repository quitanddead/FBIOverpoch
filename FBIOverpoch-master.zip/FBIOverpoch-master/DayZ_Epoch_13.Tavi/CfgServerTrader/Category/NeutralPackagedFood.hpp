class Category_687 {
	class FoodCanBakedBeans {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodCanFrankBeans {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodCanPasta {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodCanSardines {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodMRE {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class FoodPistachio {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodNutmix {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodCanUnlabeled {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodEdible {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
};
class Category_579 {
	class FoodCanBakedBeans {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodCanFrankBeans {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodCanPasta {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodCanSardines {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodMRE {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class FoodPistachio {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodNutmix {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodCanUnlabeled {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FoodEdible {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};

};