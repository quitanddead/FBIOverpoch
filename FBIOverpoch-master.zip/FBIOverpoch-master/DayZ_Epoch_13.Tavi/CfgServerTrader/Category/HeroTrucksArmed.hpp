class Category_479 {
	class ArmoredSUV_PMC_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class Pickup_PK_TK_GUE_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={100000,"Coins"};
		sell[] ={50000,"Coins"};
	};
	class Offroad_DSHKM_Gue_DZE {
		type = "trade_any_vehicle";
		buy[] ={100000,"Coins"};
		sell[] ={50000,"Coins"};
	};
	class Pickup_PK_GUE_DZE {
		type = "trade_any_vehicle";
		buy[] ={75000,"Coins"};
		sell[] ={37500,"Coins"};
	};
	class Pickup_PK_INS_DZE {
		type = "trade_any_vehicle";
		buy[] ={75000,"Coins"};
		sell[] ={37500,"Coins"};
	};
};
