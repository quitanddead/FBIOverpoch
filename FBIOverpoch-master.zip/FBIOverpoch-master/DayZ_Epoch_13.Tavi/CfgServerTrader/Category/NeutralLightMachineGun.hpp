class Category_603 {
	class M249_EP1_DZ {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class M249_DZ {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class M249 {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class M249_EP1 {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class M240_DZ {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Mk_48_DZ {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Pecheneg_DZ {
		type = "trade_weapons";
		buy[] ={30000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class RPK_74 {
		type = "trade_weapons";
		buy[] ={30000,"Coins"};
		sell[] ={15000,"Coins"};
	};
};
class Category_638 {
	class M249_EP1_DZ {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class M249_DZ {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class M249 {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class M249_EP1 {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class M240_DZ {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Mk_48_DZ {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Pecheneg_DZ {
		type = "trade_weapons";
		buy[] ={30000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class RPK_74 {
		type = "trade_weapons";
		buy[] ={30000,"Coins"};
		sell[] ={15000,"Coins"};
	};
};