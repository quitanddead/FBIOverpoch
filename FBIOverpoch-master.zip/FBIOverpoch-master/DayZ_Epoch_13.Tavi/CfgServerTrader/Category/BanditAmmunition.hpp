class Category_577 {
	class 30Rnd_556x45_StanagSD {
		type = "trade_items";
		buy[] ={400,"Coins"};
		sell[] ={200,"Coins"};
	};
	class 5Rnd_86x70_L115A1 {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class 100Rnd_762x51_M240 {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class 20Rnd_762x51_FNFAL {
		type = "trade_items";
		buy[] ={400,"Coins"};
		sell[] ={200,"Coins"};
	};
	class 20Rnd_762x51_SB_SCAR {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class  100Rnd_127x99_M2 {
		type = "trade_items";
		buy[] ={50000,"Coins"};
		sell[] ={30000,"Coins"};
	}; 
	class  2000Rnd_762x51_M134 {
		type = "trade_items";
		buy[] ={50000,"Coins"};
		sell[] ={30000,"Coins"};
	}; 
	class  32Rnd_40mm_GMG {
		type = "trade_items";
		buy[] ={50000,"Coins"};
		sell[] ={30000,"Coins"};
	}; 
	class  48Rnd_40mm_MK19 {
		type = "trade_items";
		buy[] ={50000,"Coins"};
		sell[] ={30000,"Coins"};
	};
	class  50Rnd_127x107_DSHKM {
		type = "trade_items";
		buy[] ={50000,"Coins"};
		sell[] ={30000,"Coins"};
	};
	class  29Rnd_30mm_AGS30 {
		type = "trade_items";
		buy[] ={50000,"Coins"};
		sell[] ={30000,"Coins"};
	}; 
	class  10Rnd_127x99_m107 {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	}; 
	class  5Rnd_127x99_as50 {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class  20Rnd_762x51_B_SCAR {
		type = "trade_items";
		buy[] ={500,"Coins"};
		sell[] ={250,"Coins"};
	};
	class  100Rnd_762x54_PK {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class  1Rnd_HE_M203 {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};  
	  
	
};
