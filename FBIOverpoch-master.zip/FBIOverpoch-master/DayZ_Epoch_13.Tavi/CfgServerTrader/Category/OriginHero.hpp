class Category_900 {
	class ItemSapphire {
		type = "trade_items";
		buy[] ={500000,"Coins"};
		sell[] ={10000,"Coins"};
	};
};