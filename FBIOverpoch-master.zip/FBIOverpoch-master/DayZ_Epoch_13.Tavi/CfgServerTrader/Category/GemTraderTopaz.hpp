class Category_996 {
	class M32_EP1 {
		type = "trade_weapons_old";
		buy[] = {5,"ItemTopaz"};
		sell[] = {2,"ItemTopaz"};
	};
	class M107_DZ {
		type = "trade_weapons_old";
		buy[] = {5,"ItemTopaz"};
		sell[] = {2,"ItemTopaz"};
	};
	class BAF_AS50_scoped {
		type = "trade_weapons_old";
		buy[] = {5,"ItemTopaz"};
		sell[] = {2,"ItemTopaz"};
	};
	class SMAW {
		type = "trade_weapons_old";
		buy[] = {5,"ItemTopaz"};
		sell[] = {2,"ItemTopaz"};
	};
	class AA12_PMC {
		type = "trade_weapons_old";
		buy[] = {5,"ItemTopaz"};
		sell[] = {2,"ItemTopaz"};
	};
};