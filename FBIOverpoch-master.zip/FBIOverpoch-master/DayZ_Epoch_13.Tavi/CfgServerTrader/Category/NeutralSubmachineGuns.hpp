class Category_642 {
	class bizon_silenced {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class UZI_EP1 {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class Sa61_EP1 {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class MP5A5 {
		type = "trade_weapons";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class UZI_SD_EP1 {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class MP5SD {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
};
