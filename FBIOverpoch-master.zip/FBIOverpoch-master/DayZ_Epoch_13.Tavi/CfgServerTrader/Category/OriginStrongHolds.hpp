class Category_903 {
	class ItemObsidian {
		type = "trade_items";
		buy[] ={1000000,"Coins"};
		sell[] ={10000,"Coins"};
	};
};