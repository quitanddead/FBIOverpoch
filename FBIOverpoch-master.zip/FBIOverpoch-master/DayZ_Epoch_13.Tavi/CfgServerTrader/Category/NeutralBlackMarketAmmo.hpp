class Category_527 {
	class 20Rnd_9x39_SP5_VSS {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 8Rnd_B_Beneli_74Slug {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 20Rnd_762x51_SB_SCAR {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 8Rnd_B_Beneli_Pellets {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 8Rnd_B_Saiga12_74Slug {
		type = "trade_items";
		buy[] ={150,"Coins"};
		sell[] ={75,"Coins"};
	};
	class 8Rnd_B_Saiga12_Pellets {
		type = "trade_items";
		buy[] ={150,"Coins"};
		sell[] ={75,"Coins"};
	};
	class 20Rnd_B_765x17_Ball {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 10Rnd_762x54_SVD {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 5Rnd_762x51_M24 {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class 30Rnd_556x45_Stanag {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class 20Rnd_762x51_FNFAL {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 100Rnd_556x45_BetaCMag {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class 75Rnd_545x39_RPK {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class 64Rnd_9x19_Bizon {
		type = "trade_items";
		buy[] ={300,"Coins"};
		sell[] ={150,"Coins"};
	};
	class 5Rnd_127x108_KSVK {
		type = "trade_items";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
};
