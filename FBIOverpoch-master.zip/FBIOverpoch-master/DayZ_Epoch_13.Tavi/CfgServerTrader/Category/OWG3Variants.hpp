class Category_1006 {

class vil_G3a3 {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3a2 {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3a4 {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3a4b {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3an {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3anb {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3ZF {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3zfb {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3SG1 {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3sg1b {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3TGS {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_G3TGSb {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_AG3 {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_AG3EOT {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
};