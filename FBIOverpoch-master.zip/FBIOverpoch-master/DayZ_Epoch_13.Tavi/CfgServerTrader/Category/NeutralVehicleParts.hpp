class Category_509 {
	class ItemJerrycan {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class ItemJerrycanEmpty {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class PartEngine {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class PartVRotor {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class PartWheel {
		type = "trade_items";
		buy[] ={500,"Coins"};
		sell[] ={250,"Coins"};
	};
	class PartGlass {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class PartGeneric {
		type = "trade_items";
		buy[] ={500,"Coins"};
		sell[] ={250,"Coins"};
	};
	class PartFueltank {
		type = "trade_items";
		buy[] ={500,"Coins"};
		sell[] ={250,"Coins"};
	};
	class ItemFuelBarrel {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
};
