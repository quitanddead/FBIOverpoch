class Category_651 {
	class Ikarus {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Ikarus_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class S1203_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class S1203_ambulance_EP1 {
		type = "trade_any_vehicle";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
};
class Category_588 {
	class Ikarus {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Ikarus_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class S1203_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class S1203_ambulance_EP1 {
		type = "trade_any_vehicle";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
};
