class Category_901 {
	class ItemRuby {
		type = "trade_items";
		buy[] ={500000,"Coins"};
		sell[] ={10000,"Coins"};
	};
};