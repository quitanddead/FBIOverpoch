class Category_997 {
	class vil_ori_autogyro {
		type = "trade_any_vehicle";
		buy[] ={25000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class ori_pragaCopter_yellow {
		type = "trade_any_vehicle";
		buy[] ={70000,"Coins"};
		sell[] ={35000,"Coins"};
	};
	class ori_pragaCopter_green {
		type = "trade_any_vehicle";
		buy[] ={70000,"Coins"};
		sell[] ={35000,"Coins"};
	};
	class ori_poldek {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={25000,"Coins"};
	};
	class ori_poldek_black {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={25000,"Coins"};
	};
	class ori_vil_lada_2105_rust {
		type = "trade_any_vehicle";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class ori_transit {
		type = "trade_any_vehicle";
		buy[] ={60000,"Coins"};
		sell[] ={30000,"Coins"};
	};
	class ori_originsmod_pickupoldfuel {
		type = "trade_any_vehicle";
		buy[] ={75000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class ori_vil_originsmod_lublin_truck {
		type = "trade_any_vehicle";
		buy[] ={75000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class ori_excavator {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class ori_originsmod_pickupold {
		type = "trade_any_vehicle";
		buy[] ={15000,"Coins"};
		sell[] ={7500,"Coins"};
	};
	class ori_vil_originsmod_volvo_fl290 {
		type = "trade_any_vehicle";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class ori_vil_originsmod_truck_civ {
		type = "trade_any_vehicle";
		buy[] ={60000,"Coins"};
		sell[] ={30000,"Coins"};
	};
	class ori_survivorBus {
		type = "trade_any_vehicle";
		buy[] ={75000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class SUV_MG_Ori {
		type = "trade_any_vehicle";
		buy[] ={75000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class ori_titanic {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={25000,"Coins"};
	};
	class ori_ScrapBuggy {
		type = "trade_any_vehicle";
		buy[] ={25000,"Coins"};
		sell[] ={12000,"Coins"};
	};
	class ori_rth_originsmod_bathmobile {
		type = "trade_any_vehicle";
		buy[] ={23000,"Coins"};
		sell[] ={11000,"Coins"};
	};
	class ori_p85_originsmod_cucv_pickup {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={25000,"Coins"};
	};
	class ori_p85_originsmod_CUCV {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={25000,"Coins"};
	};
	class ori_scraptank {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={25000,"Coins"};
	};
};

