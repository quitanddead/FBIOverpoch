class Category_1011 {

class USSR_cheytacM200 {type = "trade_weapons";buy[] = {500000,"Coins"};sell[] = {54000,"Coins"};};
class USSR_cheytacM200_sd {type = "trade_weapons";buy[] = {500000,"Coins"};sell[] = {54000,"Coins"};};
class FHQ_MSR_DESERT {type = "trade_weapons";buy[] = {75000,"Coins"};sell[] = {37500,"Coins"};};
class FHQ_MSR_NV_DESERT {type = "trade_weapons";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};
class FHQ_MSR_NV_SD_DESERT {type = "trade_weapons";buy[] = {85000,"Coins"};sell[] = {40000,"Coins"};};
class FHQ_MSR_SD_DESERT {type = "trade_weapons";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};
class FHQ_RSASS_SD_TAN {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
class FHQ_RSASS_TAN {type = "trade_weapons";buy[] = {35000,"Coins"};sell[] = {17500,"Coins"};};
class FHQ_XM2010_DESERT {type = "trade_weapons";buy[] = {75000,"Coins"};sell[] = {37500,"Coins"};};
class FHQ_XM2010_NV_DESERT {type = "trade_weapons";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};
class FHQ_XM2010_NV_SD_DESERT {type = "trade_weapons";buy[] = {85000,"Coins"};sell[] = {40000,"Coins"};};
class FHQ_XM2010_SD_DESERT {type = "trade_weapons";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};

class vil_SVDK {type = "trade_weapons";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
class vil_SVD_63 {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_SVD_BASE {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class vil_SVD_M {type = "trade_weapons";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
class vil_SVD_N {type = "trade_weapons";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
class vil_SVD_P21 {type = "trade_weapons";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
class vil_SVD_S {type = "trade_weapons";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
class vil_SV_98 {type = "trade_weapons";buy[] = {25000,"Coins"};sell[] = {12500,"Coins"};};
class vil_SV_98_69 {type = "trade_weapons";buy[] = {25000,"Coins"};sell[] = {12500,"Coins"};};
class vil_SV_98_SD {type = "trade_weapons";buy[] = {27000,"Coins"};sell[] = {12500,"Coins"};};
class gms_k98 {type = "trade_weapons";buy[] = {5000,"Coins"};sell[] = {2500,"Coins"};};
class gms_k98_knife {type = "trade_weapons";buy[] = {5000,"Coins"};sell[] = {2500,"Coins"};};
class gms_k98_rg {type = "trade_weapons";buy[] = {5000,"Coins"};sell[] = {2500,"Coins"};};
class gms_k98zf39 {type = "trade_weapons";buy[] = {7000,"Coins"};sell[] = {2500,"Coins"};};
};