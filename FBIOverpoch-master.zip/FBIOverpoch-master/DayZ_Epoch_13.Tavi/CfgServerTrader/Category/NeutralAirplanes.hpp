class Category_517 {
	class AN2_DZ {
		type = "trade_any_vehicle";
		buy[] ={60000,"Coins"};
		sell[] ={30000,"Coins"};
	};
	class C130J_US_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] ={500000,"Coins"};
		sell[] ={200000,"Coins"};
	};
	class MV22_DZ {
		type = "trade_any_vehicle";
		buy[] ={500000,"Coins"};
		sell[] ={200000,"Coins"};
	};
	class MV22 {
		type = "trade_any_vehicle";
		buy[] ={500000,"Coins"};
		sell[] ={200000,"Coins"};
	};
	class GNT_C185U {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class GNT_C185 {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class GNT_C185R {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class GNT_C185C {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class ori_dc3 {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class Pchela1T {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
};
