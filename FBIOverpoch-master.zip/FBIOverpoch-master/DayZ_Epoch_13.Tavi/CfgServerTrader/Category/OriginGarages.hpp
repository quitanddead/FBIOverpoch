class Category_902 {
	class ItemEmerald {
		type = "trade_items";
		buy[] ={500000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class ItemTopaz {
		type = "trade_items";
		buy[] ={300000,"Coins"};
		sell[] ={10000,"Coins"};
	};
};